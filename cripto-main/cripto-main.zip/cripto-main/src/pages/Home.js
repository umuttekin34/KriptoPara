import React from 'react'
import {Text, View } from 'react-native';
import CryptoList from '../components/CryptoList'

function Home() {
    return (
        <CryptoList/>
    )
}

export default Home
