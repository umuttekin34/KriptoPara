import React from 'react'
import { View, Text } from 'react-native'

export default function Iletisim() {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>İletişim!</Text>
            <Text>Umut TEKİN</Text>
            <Text>umut.tekin1@ogr.sakarya.edu.tr</Text>
            <Text>Nusret YILMAZ</Text>
            <Text>nusret.yilmaz1@ogr.sakarya.edu.tr</Text>
    </View>
    )
}

